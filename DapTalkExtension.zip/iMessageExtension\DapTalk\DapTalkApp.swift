import SwiftUI

@main
struct DapTalkApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
